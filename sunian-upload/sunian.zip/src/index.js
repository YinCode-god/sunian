/**
 * 苏念 · 入口
 *
 *   node src/index.js --cli     本地对话（测试手感，不连 QQ）
 *   node src/index.js           连 NapCat，收 QQ 私聊
 */
import { readFile } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createInterface } from 'node:readline';
import { Brain } from './brain.js';
import { NapCatClient } from './napcat.js';
import { sleep } from './pacing.js';
import { stamp } from './memory.js';
import { loadApiKey, maskKey } from './credentials.js';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, '..');

function line(s) { process.stdout.write(s + '\n'); }
function ts() { return new Date().toLocaleTimeString('zh-CN', { hour12: false }); }
function log(s) { line('[' + ts() + '] ' + s); }

async function loadConfig() {
  const raw = await readFile(join(ROOT, 'config.json'), 'utf8');
  return JSON.parse(raw);
}

/** 按延迟把她的话一条条打出来（CLI 用） */
export async function deliver(parsed) {
  for (let i = 0; i < parsed.messages.length; i++) {
    await sleep(parsed.delays[i]);
    line('');
    line('  苏念 ' + stamp() + '  (' + (parsed.delays[i] / 1000).toFixed(1) + 's)');
    line('  ' + parsed.messages[i]);
  }
  line('');
  if (parsed.degraded) line('  [!] 模型这次没按 JSON 返回，已降级处理');
  line('');
}

/* ---------------------------------- CLI ---------------------------------- */

async function cli() {
  const config = await loadConfig();
  line('======================================');
  line('  苏念 · 本地对话测试');
  line('======================================');

  const brain = new Brain(config);
  await brain.init();

  const { key, source } = await loadApiKey(config.provider.apiKeyRefs);
  line('模型    : ' + config.provider.model);
  line('接口    : ' + config.provider.baseUrl);
  line('密钥    : ' + maskKey(key) + '  (来自 ' + source + ')');
  line('记忆    : data/ 目录下的 Markdown 文件');
  line('历史    : 已载入 ' + brain.history.length + ' 条');
  line('');
  line('直接打字和她说话。/quit 退出，/clear 清空对话历史。');
  line('--------------------------------------');

  const rl = createInterface({ input: process.stdin, output: process.stdout, terminal: false });
  const queue = [];
  let running = true;
  rl.on('line', (raw) => queue.push(raw));

  while (running) {
    if (queue.length === 0) { await sleep(80); continue; }
    const text = String(queue.shift()).trim();
    if (!text) continue;
    if (text === '/quit' || text === '/exit') break;
    if (text === '/clear') {
      const { clearHistory } = await import('./memory.js');
      await clearHistory();
      brain.history = [];
      line('  （对话历史已清空，档案和情绪日志保留）');
      continue;
    }
    line('');
    line('  你 ' + stamp());
    line('  ' + text);
    try {
      await deliver(await brain.respond(text));
    } catch (err) {
      line('');
      line('  [x] ' + err.message);
      line('');
    }
  }
  rl.close();
  line('（苏念下线了）');
}

/* ---------------------------------- QQ ----------------------------------- */

async function qq() {
  const config = await loadConfig();
  const brain = new Brain(config);
  await brain.init();

  const { key, source } = await loadApiKey(config.provider.apiKeyRefs);
  log('模型 ' + config.provider.model + '  密钥 ' + maskKey(key) + ' (' + source + ')');
  log('历史 ' + brain.history.length + ' 条');

  let lastUserAt = null;
  const queue = [];
  let working = false;

  async function pump() {
    if (working) return;
    working = true;
    while (queue.length) {
      const msg = queue.shift();
      lastUserAt = new Date();
      try {
        const parsed = await brain.respond(msg.text);
        log('-> ' + msg.userId + '  (共 ' + parsed.messages.length + ' 条)');
        for (const m of parsed.messages) log('   苏念: ' + m);
        await client.sendSequence(msg.userId, parsed.messages, parsed.delays, {
          onSent: (m) => log('   [已发送] ' + m)
        });
      } catch (err) {
        log('[x] 处理失败: ' + err.message);
      }
    }
    working = false;
  }

  const client = new NapCatClient({
    url: config.qq.wsUrl,
    token: config.qq.token,
    onLog: log,
    onPrivate: (ev) => {
      const owner = config.owner.qq;
      if (owner && String(ev.userId) !== String(owner)) {
        log('忽略非本人消息: ' + ev.userId);
        return;
      }
      if (!ev.text || !ev.text.trim()) return;
      log('<- ' + ev.userId + ': ' + ev.text);
      queue.push(ev);
      pump();
    }
  });

  client.connect();

  process.on('SIGINT', () => {
    log('收到退出信号，正在断开');
    client.close();
    process.exit(0);
  });

  // 心跳日志
  setInterval(() => {
    const silence = lastUserAt ? Math.round((Date.now() - lastUserAt.getTime()) / 60000) : '-';
    if (client.connected) log('在线 · 队列 ' + queue.length + ' · 距上次说话 ' + silence + ' 分钟');
  }, 10 * 60 * 1000);
}

/* --------------------------------- 启动 ---------------------------------- */

const mode = process.argv.includes('--cli') ? 'cli' : 'qq';
if (mode === 'cli') {
  cli().catch((err) => { console.error('启动失败：' + err.message); process.exit(1); });
} else {
  qq().catch((err) => { console.error('启动失败：' + err.message); process.exit(1); });
}
