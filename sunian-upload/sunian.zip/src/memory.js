/**
 * 记忆系统：全部用 Markdown 文件，人和 AI 都能直接读改。
 *
 *   data/用户档案.md    关于他的事实，长期积累
 *   data/情绪日志.md    时间线：什么时候发生了什么，情绪如何
 *   data/苏念的日常.md  她自己的生活状态，会演变
 *   data/关系温度.md    你们最近的关系状态
 *   data/history.json   原始对话历史（给模型看的上下文）
 */
import { readFile, writeFile, appendFile, mkdir } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
export const DATA_DIR = join(HERE, '..', 'data');

const F = {
  profile: join(DATA_DIR, '用户档案.md'),
  log: join(DATA_DIR, '情绪日志.md'),
  daily: join(DATA_DIR, '苏念的日常.md'),
  warmth: join(DATA_DIR, '关系温度.md'),
  history: join(DATA_DIR, 'history.json'),
  pending: join(DATA_DIR, '主动性排队.json')
};

function pad(n) { return String(n).padStart(2, '0'); }

export function stamp(d) {
  const t = d || new Date();
  return t.getFullYear() + '-' + pad(t.getMonth() + 1) + '-' + pad(t.getDate())
    + ' ' + pad(t.getHours()) + ':' + pad(t.getMinutes());
}

export function dateOnly(d) {
  const t = d || new Date();
  return t.getFullYear() + '-' + pad(t.getMonth() + 1) + '-' + pad(t.getDate());
}

async function readOr(path, fallback) {
  try { return await readFile(path, 'utf8'); }
  catch { return fallback; }
}

export async function ensureDataDir() {
  await mkdir(DATA_DIR, { recursive: true });
  const defaults = [
    [F.profile, '# 用户档案\n\n> 关于 ybh 的事实，慢慢积累。你可以直接编辑这个文件。\n\n## 基本情况\n\n（还没聊到）\n\n## 在意的人和事\n\n（还没聊到）\n\n## 他的习惯\n\n（还没聊到）\n'],
    [F.log, '# 情绪日志\n\n> 每次对话里值得记的事，程序会自动追加。\n\n| 时间 | 事情 | 情绪 | 强度 |\n|---|---|---|---|\n'],
    [F.daily, '# 苏念的日常\n\n> 她自己的生活状态。会随时间和聊天演变。\n\n## 今天\n\n- 还没开始\n\n## 最近在烦的\n\n- 期末论文选题还被导师压着\n\n## 一直在追的\n\n- 一部慢节奏日剧，看到第三集睡着了三次\n- 重读《人间失格》，不敢一次读完\n\n## 球球（多肉）\n\n- 活着，但状态一般\n'],
    [F.warmth, '# 关系温度\n\n> 程序自动维护。\n\n- 最后一次说话：（还没聊过）\n- 已经几天没理她：0\n- 她此刻的心情：平静\n- 有没有在生他的气：没有\n']
  ];
  for (const [path, content] of defaults) {
    try { await readFile(path, 'utf8'); }
    catch { await writeFile(path, content, 'utf8'); }
  }
}

/**
 * 把「现在是什么时候」变成她能读懂的上下文。
 * 没有这个，她不知道几点、不知道你多久没找她，说话就会不着调。
 */
export async function buildTimeContext() {
  const now = new Date();
  const week = ["日", "一", "二", "三", "四", "五", "六"][now.getDay()];
  const h = now.getHours();
  const mi = String(now.getMinutes()).padStart(2, "0");

  let period;
  if (h < 5) period = "凌晨";
  else if (h < 9) period = "早上";
  else if (h < 12) period = "上午";
  else if (h < 14) period = "中午";
  else if (h < 18) period = "下午";
  else if (h < 23) period = "晚上";
  else period = "深夜";

  const lines = [];
  lines.push("现在是 " + now.getFullYear() + " 年 " + (now.getMonth() + 1) + " 月 " + now.getDate()
    + " 日 星期" + week + "，" + period + " " + h + ":" + mi + "。");

  // 距上次说话多久（从关系温度里读）
  let mid = null;
  try {
    const warmth = await readOr(PATHS.warmth, "");
    const m = warmth.match(/最后一次说话：(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2})/);
    if (m) mid = new Date(m[1] + "T" + m[2] + ":00");
  } catch {}

  if (mid && !isNaN(mid.getTime())) {
    const mins = Math.floor((now.getTime() - mid.getTime()) / 60000);
    if (mins < 2) lines.push("你们刚刚还在说话。");
    else if (mins < 60) lines.push("你们上一次说话是 " + mins + " 分钟前。");
    else if (mins < 60 * 24) lines.push("你们上一次说话是 " + Math.floor(mins / 60) + " 小时前。");
    else {
      const days = Math.floor(mins / (60 * 24));
      lines.push("他已经 " + days + " 天没找你了。");
    }
  } else {
    lines.push("你们还没正式聊过。");
  }

  lines.push("");
  lines.push("如果有人问你几点了，你会像真人一样看一眼手机再说——比如「都快十一点了」、");
  lines.push("「十点五十几，你问这个干嘛」。千万别说「我不知道」——你手上就有手机。");
  lines.push("");
  lines.push("平时不要动不动就报时间，那很假。时间感要藏在话里：");
  lines.push("- 凌晨还醒着：该催他睡了（「都几点了」「手机放下」）");
  lines.push("- 早上：问他醒了没、吃早饭没");
  lines.push("- 中午晚上：问他吃了没");
  lines.push("- 他好几天没来：你是真的会数天数的，该不高兴");
  lines.push("- 他刚走又回来：可以打趣一句");

  return lines.join("\n");
}

/** 拼出注入给模型的记忆上下文 */
export async function loadMemory() {
  const [profile, log, daily, warmth] = await Promise.all([
    readOr(F.profile, ''),
    readOr(F.log, ''),
    readOr(F.daily, ''),
    readOr(F.warmth, '')
  ]);

  const logLines = log.split(/\r?\n/).filter(function (l) { return l.trim().startsWith('|') && !l.includes('---') && !l.includes('时间'); });
  const recent = logLines.slice(-20).join('\n');

  return [
    '## 现在是什么时候\n' + (await buildTimeContext()),
    '## 关于他\n' + profile.trim(),
    '## 最近发生的事（越靠后越新）\n' + (recent || '（还没有记录）'),
    '## 你自己的生活\n' + daily.trim(),
    '## 你们现在的关系状态\n' + warmth.trim()
  ].join('\n\n');
}

/** 记一条情绪日志 */
export async function appendLog(userText, state) {
  if (!state || !state.event) return false;
  const emo = state.his_emotion || '—';
  const inten = (state.intensity === null || state.intensity === undefined) ? '—' : state.intensity;
  const row = '| ' + stamp() + ' | ' + String(state.event).replace(/\|/g, '/') + ' | ' + emo + ' | ' + inten + ' |\n';
  await appendFile(F.log, row, 'utf8');
  return true;
}

/** 更新关系温度 */
export async function touchWarmth(info) {
  const days = info.daysSilent === undefined ? 0 : info.daysSilent;
  const mood = info.mood || '平静';
  const angry = info.angry ? '有，正在生他的气' : '没有';
  const last = info.lastText ? ('「' + String(info.lastText).slice(0, 40) + '」') : '（还没聊过）';

  const body = [
    '# 关系温度',
    '',
    '> 程序自动维护。',
    '',
    '- 最后一次说话：' + stamp() + ' ' + last,
    '- 已经几天没理她：' + days,
    '- 她此刻的心情：' + mood,
    '- 有没有在生他的气：' + angry,
    ''
  ].join('\n');
  await writeFile(F.warmth, body, 'utf8');
}

/** 对话历史 */
export async function loadHistory() {
  const raw = await readOr(F.history, '[]');
  try {
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch { return []; }
}

export async function saveHistory(history) {
  await writeFile(F.history, JSON.stringify(history, null, 2), 'utf8');
}

/** 清空对话历史（记忆文件保留） */
export async function clearHistory() {
  await saveHistory([]);
}

export const PATHS = F;
