/**
 * 模型调用：OpenAI 兼容的 chat/completions 接口。
 * 只用 Node 24 自带的 fetch，不依赖任何第三方库。
 */
import { loadApiKey } from './credentials.js';

export class Llm {
  constructor(cfg) {
    this.baseUrl = cfg.baseUrl.replace(/\/+$/, '');
    this.model = cfg.model;
    this.temperature = cfg.temperature;
    this.maxTokens = cfg.maxTokens;
    this.timeoutMs = cfg.timeoutMs || 60000;
    this.apiKeyRefs = cfg.apiKeyRefs || [];
    this.apiKey = null;
    this.apiKeySource = null;
  }

  async ready() {
    if (!this.apiKey) {
      const { key, source } = await loadApiKey(this.apiKeyRefs);
      this.apiKey = key;
      this.apiKeySource = source;
    }
    return this;
  }

  /**
   * @param {{system: string, messages: Array<{role:string, content:string}>, jsonMode?: boolean}} opts
   * @returns {Promise<string>} 模型返回的文本
   */
  async complete(opts) {
    await this.ready();

    const body = {
      model: this.model,
      temperature: this.temperature,
      max_tokens: this.maxTokens,
      messages: [{ role: 'system', content: opts.system }, ...opts.messages]
    };
    if (opts.jsonMode) {
      body.response_format = { type: 'json_object' };
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);

    let res;
    try {
      res = await fetch(this.baseUrl + '/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.apiKey
        },
        body: JSON.stringify(body),
        signal: controller.signal
      });
    } catch (err) {
      clearTimeout(timer);
      throw new Error('连接模型失败：' + err.message);
    }
    clearTimeout(timer);

    const text = await res.text();
    if (!res.ok) {
      throw new Error('模型返回 ' + res.status + '：' + text.slice(0, 400));
    }

    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error('模型返回的不是 JSON：' + text.slice(0, 400));
    }

    const choice = data.choices && data.choices[0];
    const content = choice && choice.message && choice.message.content;
    if (!content) {
      throw new Error('模型没有返回内容：' + text.slice(0, 400));
    }
    return content;
  }
}
