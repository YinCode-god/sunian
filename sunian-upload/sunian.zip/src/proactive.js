/**
 * 主动消息：她最多每天主动找他说一次，而且只接上次聊过的话题。
 *
 * 原则（来自需求确认单）：
 *   - 每天最多 1 次
 *   - 不打扰：安静时段不发
 *   - 必须接得上上次的话题，不做空洞的「在吗」
 */
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { PATHS, dateOnly, loadMemory } from './memory.js';
import { buildSystemPrompt } from './persona.js';

const STATE = join(PATHS.warmth, '..', '主动性状态.json');

function pad(n) { return String(n).padStart(2, '0'); }

async function readState() {
  try {
    const raw = await readFile(STATE, 'utf8');
    const s = JSON.parse(raw);
    return {
      lastProactiveDate: s.lastProactiveDate || null,
      totalProactive: s.totalProactive || 0,
      lastUserAt: s.lastUserAt || null
    };
  } catch {
    return { lastProactiveDate: null, totalProactive: 0, lastUserAt: null };
  }
}

async function writeState(s) {
  await writeFile(STATE, JSON.stringify(s, null, 2), 'utf8');
}

export async function noteUserActivity() {
  const s = await readState();
  s.lastUserAt = new Date().toISOString();
  await writeState(s);
}

/**
 * 判断现在该不该主动说话。
 * @returns {{should: boolean, reason: string}}
 */
export async function shouldReachOut(cfg) {
  const c = cfg || {};
  if (!c.enabled) return { should: false, reason: '主动消息未开启' };

  const now = new Date();
  const hour = now.getHours();
  const quiet = c.quietHours || [];
  if (quiet.indexOf(hour) >= 0) return { should: false, reason: '现在是安静时段（' + hour + ' 点）' };

  const s = await readState();
  const today = dateOnly(now);
  if (s.lastProactiveDate === today) return { should: false, reason: '今天已经主动找过他了' };

  const maxPerDay = c.maxPerDay === undefined ? 1 : c.maxPerDay;
  const silentHours = c.minSilentHours === undefined ? 20 : c.minSilentHours;
  if (s.lastUserAt) {
    const gap = (now.getTime() - new Date(s.lastUserAt).getTime()) / 3600000;
    if (gap < silentHours) {
      return { should: false, reason: '距上次说话才 ' + gap.toFixed(1) + ' 小时，还不用主动找' };
    }
  } else {
    return { should: false, reason: '还没聊过，不适合主动开口' };
  }

  return { should: true, reason: '可以主动找他了' };
}

/** 生成一条主动消息（用她自己的语气，接上次的话题） */
export async function composeReachOut(llm, config) {
  const memText = await loadMemory();
  const now = new Date();
  const hour = now.getHours();
  const when = hour < 11 ? '早上' : (hour < 14 ? '中午' : (hour < 18 ? '下午' : (hour < 23 ? '晚上' : '深夜')));

  const system = buildSystemPrompt(memText) + [

    '',
    '---',
    '',
    '# 现在的情况',
    '',
    '现在是你主动找他说话，不是他先找你。',
    '时间是' + when + ' ' + pad(now.getHours()) + ':' + pad(now.getMinutes()) + '。',
    '',
    '要求：',
    '- 接得上你们上次聊过的事。不要发「在吗」「最近怎么样」这种空话。',
    '- 可以是你自己的生活小事，也可以是惦记他上次说的事。',
    '- 不要提「你好几天没理我了」这种指责，除非你确实要闹小脾气（他状态好才可以）。',
    '- 一到两条就够了，短。'
  ].join('\n');

  const raw = await llm.complete({
    system: system,
    messages: [{ role: 'user', content: '（现在轮到你主动开口了，说点什么吧）' }],
    jsonMode: true
  });

  return raw;
}

export async function markReachedOut() {
  const s = await readState();
  s.lastProactiveDate = dateOnly();
  s.totalProactive += 1;
  await writeState(s);
}
