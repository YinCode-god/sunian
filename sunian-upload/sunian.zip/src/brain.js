/**
 * 苏念的大脑：把人格、记忆、历史、模型串起来。
 */
import { Llm } from './llm.js';
import { loadOverrides } from './credentials.js';
import { buildSystemPrompt } from './persona.js';
import * as memory from './memory.js';
import { splitLong, planDelays } from './pacing.js';

/**
 * 模型有时候会裹上 markdown 代码块或者多说两句。
 * 这里尽量把它逼回一个 JSON 对象；实在不行就退化成「整段话当一条消息」。
 */
export function parseReply(raw) {
  let text = String(raw || '').trim();

  // 去掉 markdown 代码块围栏
  const fence = text.match(/^[\s\S]*?\x60\x60\x60(?:json)?\s*([\s\S]*?)\x60\x60\x60/);
  if (fence) text = fence[1].trim();

  // 截取最外层的花括号
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start >= 0 && end > start) {
    const candidate = text.slice(start, end + 1);
    try {
      const obj = JSON.parse(candidate);
      const msgs = Array.isArray(obj.messages) ? obj.messages : null;
      if (msgs && msgs.length) {
        return {
          messages: msgs.map(function (m) { return String(m).trim(); }).filter(Boolean),
          delays: Array.isArray(obj.delays) ? obj.delays : [],
          state: obj.state || {},
          raw: raw
        };
      }
    } catch { /* 落到下面的兜底 */ }
  }

  // 兜底：模型没按格式来，就把返回的文字本身当成她说的话
  const fallback = text.replace(/^["']|["']$/g, '').trim();
  return {
    messages: fallback ? [fallback] : ['（苏念没说话）'],
    delays: [],
    state: {},
    raw: raw,
    degraded: true
  };
}

export class Brain {
  constructor(config) {
    this.config = config;
    this.llm = new Llm({
      baseUrl: config.provider.baseUrl,
      model: config.provider.model,
      apiKeyRefs: config.provider.apiKeyRefs,
      temperature: config.generation.temperature,
      maxTokens: config.generation.maxTokens,
      timeoutMs: config.generation.timeoutMs
    });
    this.history = [];
    this.lastInteraction = null;
  }

  async init() {
    await memory.ensureDataDir();

    // .env 里若写了 SUNIAN_BASE_URL / SUNIAN_MODEL，覆盖 config.json 的默认值
    const ov = await loadOverrides();
    if (ov.baseUrl) this.llm.baseUrl = ov.baseUrl.replace(/\/+$/, '');
    if (ov.model) this.llm.model = ov.model;
    if (typeof ov.temperature === 'number' && !Number.isNaN(ov.temperature)) {
      this.llm.temperature = ov.temperature;
    }

    this.history = await memory.loadHistory();
    return this;
  }

  /** 回复一条消息 */
  async respond(userText, opts) {
    const o = opts || {};
    const memText = await memory.loadMemory();
    const system = buildSystemPrompt(memText);

    const messages = this.history.slice(-this.config.history.maxTurns * 2);
    messages.push({ role: 'user', content: userText });

    const raw = await this.llm.complete({ system: system, messages: messages, jsonMode: true });
    const parsed = parseReply(raw);

    // 线程历史（存模型原始输出，让它自己保持格式一致）
    this.history.push({ role: 'user', content: userText });
    this.history.push({ role: 'assistant', content: raw });
    const cap = this.config.history.maxTurns * 2;
    if (this.history.length > cap) this.history = this.history.slice(-cap);
    await memory.saveHistory(this.history);

    // 记忆
    await memory.appendLog(userText, parsed.state);
    const st = parsed.state || {};
    await memory.touchWarmth({
      lastText: userText,
      mood: st.phase === '危机' ? '很担心他' : '平静',
      angry: false,
      daysSilent: 0
    });
    this.lastInteraction = new Date();

    // 兜底再拆一次超长消息
    const expanded = [];
    for (const m of parsed.messages) {
      for (const piece of splitLong(m, 25)) expanded.push(piece);
    }
    parsed.messages = expanded;
    parsed.delays = planDelays(expanded, parsed.delays, this.config.pacing);
    return parsed;
  }
}
